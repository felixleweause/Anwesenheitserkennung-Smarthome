var mysql = require('mysql');
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'SmartCoast',
    password : '123VORbei!',
    database : 'esp_ble'
});
var data = {"personen": [] , "rooms": [] , "scanner_micro": [] };
connection.connect(function(error){
	if(!!error) {
		console.log(error);
	} else {
        connection.query("SELECT * FROM rooms", function(err,result){
            data.rooms = result;
            connection.query("SELECT * FROM personen", function(err,results){
                data.personen = results;
            });
            connection.query("SELECT * FROM scanner_micro", function(err,results){
                data.scanner_micro = results;
            });
        });
		console.log('Connected..!');
	}
});
module.exports = {connection: connection, data: data};