var brain = require('brain.js');
const fs = require('fs');
var net = new brain.NeuralNetwork();
var data_tmp_ = [];
fs.readFile('/home/pi/config/neural.json', function(err, data) { 
    //t
    if(data.length != 0){    
        var neural = JSON.parse(data); 
        net.fromJSON(neural);
    }
});

var train = function(){
    console.log(data_tmp_);
    net.train(data_tmp_, {iterations: 20000, log: true});
    var json = net.toJSON();
    fs.writeFile('/home/pi/config/neural.json',JSON.stringify(json),function(err){
        if(err) throw err;
    })
}
var run = function(data){
    var output = net.run(data);
    return output;
}
var storedatatmp = function(data){
    data.forEach(element => {
        data_tmp_.push(element);
    });
    console.log("data_tmp_");
    console.log(data_tmp_);
}
var reset = function(){
    fs.writeFile('/home/pi/config/neural.json',"",function(err){
        if(err) throw err;
    })
}
module.exports = {train: train, run: run, storedatatmp: storedatatmp, reset : reset};