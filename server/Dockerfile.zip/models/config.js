var connection  = require('../models/db.js');
var write = function (titel , value ){
    connection.query("UPDATE config SET value='" + value +  "' WHERE titel='" + titel + "'", function(err, result) {
    });
}
var read = function (titel){
    connection.query("SELECT value FROM config WHERE titel='" + titel + "'", function(err, result) {
        return result[0]['value'];
    });
}